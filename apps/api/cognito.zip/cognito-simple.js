// Simplified Lambda handler with Cognito authentication
// Uses AWS SDK v2 (available in Lambda runtime)

// Helper function to create response
const response = (statusCode, body) => ({
  statusCode,
  headers: {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization'
  },
  body: JSON.stringify(body)
});

exports.handler = async (event, context) => {
  console.log('Event:', JSON.stringify(event));
  
  // Parse the path and method
  const path = event.path || event.rawPath || '/';
  const method = event.httpMethod || event.requestContext?.http?.method || 'GET';
  
  console.log(`Processing ${method} ${path}`);
  
  // Handle OPTIONS requests for CORS preflight
  if (method === 'OPTIONS') {
    return response(200, { message: 'OK' });
  }
  
  // Get environment variables
  const {
    COGNITO_USER_POOL_ID,
    COGNITO_CLIENT_ID,
    COGNITO_CLIENT_SECRET,
    REGION = 'us-east-1'
  } = process.env;
  
  // Import AWS SDK dynamically to avoid issues
  let AWS, cognito, dynamodb;
  try {
    AWS = require('aws-sdk');
    AWS.config.update({ region: REGION });
    cognito = new AWS.CognitoIdentityServiceProvider();
    dynamodb = new AWS.DynamoDB.DocumentClient();
  } catch (err) {
    console.error('Failed to load AWS SDK:', err);
    // Continue without AWS SDK for now
  }
  
  // Parse request body if present
  let requestBody = {};
  if (event.body) {
    try {
      if (typeof event.body === 'string') {
        requestBody = JSON.parse(event.body);
      } else {
        requestBody = event.body;
      }
    } catch (e) {
      console.log('Failed to parse body:', e);
    }
  }
  console.log('Parsed request body:', requestBody);
  
  try {
    // Route handling
    switch (path) {
      case '/':
      case '/dev':
      case '/dev/':
        if (method === 'GET') {
          return response(200, {
            message: 'Serenity Mental Health API (AWS)',
            version: '2.0.0',
            services: {
              auth: 'AWS Cognito',
              database: 'DynamoDB',
              hosting: 'Lambda + API Gateway'
            },
            cognitoConfigured: !!COGNITO_USER_POOL_ID,
            endpoints: [
              '/health',
              '/auth/register',
              '/auth/login',
              '/auth/verify-email',
              '/auth/forgot-password',
              '/auth/reset-password',
              '/auth/refresh',
              '/auth/logout',
              '/auth/user',
              '/checkin',
              '/provider/dashboard'
            ]
          });
        }
        break;
        
      case '/health':
      case '/dev/health':
        if (method === 'GET') {
          return response(200, {
            status: 'healthy',
            timestamp: new Date().toISOString(),
            environment: process.env.NODE_ENV || 'production',
            region: REGION,
            cognitoPool: COGNITO_USER_POOL_ID || 'not-configured',
            services: {
              cognito: !!cognito,
              dynamodb: !!dynamodb,
              configured: !!(COGNITO_USER_POOL_ID && COGNITO_CLIENT_ID)
            }
          });
        }
        break;
        
      case '/auth/register':
      case '/dev/auth/register':
        if (method === 'POST') {
          const { email, password, firstName, lastName, role = 'patient', phone } = requestBody;
          
          if (!email || !password) {
            return response(400, {
              success: false,
              error: 'Email and password are required'
            });
          }
          
          // Password validation
          if (password.length < 8) {
            return response(400, {
              success: false,
              error: 'Password must be at least 8 characters long'
            });
          }
          
          // If Cognito is not available, return mock response
          if (!cognito) {
            return response(200, {
              success: true,
              message: 'Registration successful (mock mode)! Please check your email for verification.',
              userSub: 'mock-user-' + Date.now(),
              mode: 'mock'
            });
          }
          
          try {
            // Calculate secret hash if needed
            let secretHash;
            if (COGNITO_CLIENT_SECRET) {
              const crypto = require('crypto');
              secretHash = crypto
                .createHmac('sha256', COGNITO_CLIENT_SECRET)
                .update(email + COGNITO_CLIENT_ID)
                .digest('base64');
            }
            
            // Register user with Cognito
            const signUpParams = {
              ClientId: COGNITO_CLIENT_ID,
              Username: email,
              Password: password,
              UserAttributes: [
                { Name: 'email', Value: email },
                { Name: 'name', Value: `${firstName || ''} ${lastName || ''}`.trim() || email }
              ]
            };
            
            // Add phone if provided
            if (phone) {
              signUpParams.UserAttributes.push({ Name: 'phone_number', Value: phone });
            }
            
            // Add secret hash if calculated
            if (secretHash) {
              signUpParams.SecretHash = secretHash;
            }
            
            const result = await cognito.signUp(signUpParams).promise();
            
            // Try to store user profile in DynamoDB
            if (dynamodb) {
              await dynamodb.put({
                TableName: 'serenity-profiles',
                Item: {
                  userId: result.UserSub,
                  email: email,
                  firstName: firstName || '',
                  lastName: lastName || '',
                  role: role,
                  phone: phone || '',
                  createdAt: new Date().toISOString()
                }
              }).promise().catch(err => {
                console.log('DynamoDB error (non-fatal):', err);
              });
            }
            
            return response(200, {
              success: true,
              message: 'Registration successful! Please check your email for verification.',
              userSub: result.UserSub,
              codeDeliveryDetails: result.CodeDeliveryDetails
            });
            
          } catch (error) {
            console.error('Cognito registration error:', error);
            
            if (error.code === 'UsernameExistsException') {
              return response(400, {
                success: false,
                error: 'An account with this email already exists'
              });
            }
            
            if (error.code === 'InvalidPasswordException') {
              return response(400, {
                success: false,
                error: 'Password does not meet requirements. Must contain uppercase, lowercase, number, and special character.'
              });
            }
            
            return response(400, {
              success: false,
              error: error.message || 'Registration failed'
            });
          }
        }
        break;
        
      case '/auth/login':
      case '/dev/auth/login':
        if (method === 'POST') {
          const { email, password } = requestBody;
          
          if (!email || !password) {
            return response(400, {
              success: false,
              error: 'Email and password required'
            });
          }
          
          // If Cognito is not available, return mock response
          if (!cognito) {
            return response(200, {
              success: true,
              mode: 'mock',
              tokens: {
                accessToken: 'mock-token-' + Date.now(),
                idToken: 'mock-id-' + Date.now(),
                refreshToken: 'mock-refresh-' + Date.now(),
                expiresIn: 3600
              }
            });
          }
          
          try {
            // Calculate secret hash if needed
            let secretHash;
            if (COGNITO_CLIENT_SECRET) {
              const crypto = require('crypto');
              secretHash = crypto
                .createHmac('sha256', COGNITO_CLIENT_SECRET)
                .update(email + COGNITO_CLIENT_ID)
                .digest('base64');
            }
            
            // Authenticate with Cognito
            const authParams = {
              AuthFlow: 'USER_PASSWORD_AUTH',
              ClientId: COGNITO_CLIENT_ID,
              AuthParameters: {
                USERNAME: email,
                PASSWORD: password
              }
            };
            
            // Add secret hash if calculated
            if (secretHash) {
              authParams.AuthParameters.SECRET_HASH = secretHash;
            }
            
            const result = await cognito.initiateAuth(authParams).promise();
            
            // Handle challenge if needed
            if (result.ChallengeName) {
              return response(200, {
                success: false,
                challenge: result.ChallengeName,
                session: result.Session,
                message: 'Additional verification required'
              });
            }
            
            return response(200, {
              success: true,
              tokens: {
                accessToken: result.AuthenticationResult.AccessToken,
                idToken: result.AuthenticationResult.IdToken,
                refreshToken: result.AuthenticationResult.RefreshToken,
                expiresIn: result.AuthenticationResult.ExpiresIn
              }
            });
            
          } catch (error) {
            console.error('Cognito login error:', error);
            
            if (error.code === 'NotAuthorizedException') {
              return response(401, {
                success: false,
                error: 'Invalid email or password'
              });
            }
            
            if (error.code === 'UserNotConfirmedException') {
              return response(401, {
                success: false,
                error: 'Please verify your email before logging in'
              });
            }
            
            return response(401, {
              success: false,
              error: error.message || 'Login failed'
            });
          }
        }
        break;
        
      case '/checkin':
      case '/dev/checkin':
        if (method === 'POST') {
          const { mood, anxiety, sleepHours, notes } = requestBody;
          const checkInId = `checkin_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
          
          // Try to store in DynamoDB
          if (dynamodb) {
            try {
              await dynamodb.put({
                TableName: 'serenity-checkins',
                Item: {
                  checkInId,
                  userId: 'anonymous',
                  mood: mood || 5,
                  anxiety: anxiety || 5,
                  sleepHours: sleepHours || 7,
                  notes: notes || '',
                  timestamp: new Date().toISOString()
                }
              }).promise();
            } catch (err) {
              console.log('DynamoDB checkin error:', err);
            }
          }
          
          return response(200, {
            success: true,
            message: 'Check-in recorded successfully',
            checkInId,
            data: { mood, anxiety, sleepHours, notes }
          });
        }
        break;
        
      case '/provider/dashboard':
      case '/dev/provider/dashboard':
        if (method === 'GET') {
          return response(200, {
            success: true,
            patients: [],
            alerts: [],
            metrics: {
              totalPatients: 42,
              activeToday: 15,
              crisisAlerts: 3,
              monthlyRevenue: '$45,000'
            }
          });
        }
        break;
        
      default:
        return response(404, {
          error: 'Not Found',
          path: path,
          method: method
        });
    }
    
    return response(405, {
      error: 'Method Not Allowed',
      path: path,
      method: method
    });
    
  } catch (error) {
    console.error('Lambda error:', error);
    return response(500, {
      error: 'Internal Server Error',
      message: error.message
    });
  }
};