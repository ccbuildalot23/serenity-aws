// AWS Lambda handler using AWS SDK v3 (available in Node.js 20 runtime)
const crypto = require('crypto');

// Helper to calculate secret hash for Cognito
const calculateSecretHash = (username, clientId, clientSecret) => {
  if (!clientSecret) return undefined;
  return crypto
    .createHmac('sha256', clientSecret)
    .update(username + clientId)
    .digest('base64');
};

exports.handler = async (event, context) => {
  console.log('Event:', JSON.stringify(event));
  
  // Parse the path and method
  const path = event.path || event.rawPath || '/';
  const method = event.httpMethod || event.requestContext?.http?.method || 'GET';
  
  console.log(`Processing ${method} ${path}`);
  
  // Helper function to create response
  const response = (statusCode, body) => ({
    statusCode,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token'
    },
    body: JSON.stringify(body)
  });
  
  // Handle OPTIONS requests for CORS preflight
  if (method === 'OPTIONS') {
    return response(200, { message: 'OK' });
  }
  
  // Get environment variables
  const {
    COGNITO_USER_POOL_ID,
    COGNITO_CLIENT_ID,
    COGNITO_CLIENT_SECRET,
    REGION = 'us-east-1'
  } = process.env;
  
  // Initialize AWS SDK v3 clients
  let cognito, dynamodb;
  try {
    const { CognitoIdentityProviderClient, SignUpCommand, InitiateAuthCommand, GetUserCommand } = require('@aws-sdk/client-cognito-identity-provider');
    const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
    const { DynamoDBDocumentClient, PutCommand, GetCommand } = require('@aws-sdk/lib-dynamodb');
    
    cognito = new CognitoIdentityProviderClient({ region: REGION });
    const ddbClient = new DynamoDBClient({ region: REGION });
    dynamodb = DynamoDBDocumentClient.from(ddbClient);
  } catch (err) {
    console.error('Failed to load AWS SDK v3:', err);
    return response(500, {
      error: 'AWS SDK initialization failed',
      details: err.message
    });
  }
  
  try {
    // Parse request body if present
    let requestBody = {};
    if (event.body) {
      try {
        if (typeof event.body === 'string') {
          requestBody = JSON.parse(event.body);
        } else {
          requestBody = event.body;
        }
      } catch (e) {
        console.log('Failed to parse body:', e);
      }
    }
    console.log('Parsed request body:', requestBody);
    
    // Route handling
    switch (path) {
      case '/':
      case '/dev':
      case '/dev/':
        if (method === 'GET') {
          return response(200, {
            message: 'Serenity Mental Health API (AWS)',
            version: '3.0.0',
            services: {
              auth: 'AWS Cognito',
              database: 'DynamoDB',
              hosting: 'Lambda + API Gateway'
            },
            cognitoConfigured: !!COGNITO_USER_POOL_ID,
            sdkVersion: 'v3',
            endpoints: [
              '/health',
              '/auth/register',
              '/auth/login',
              '/auth/verify-email',
              '/auth/user',
              '/checkin',
              '/provider/dashboard'
            ]
          });
        }
        break;
        
      case '/health':
      case '/dev/health':
        if (method === 'GET') {
          return response(200, {
            status: 'healthy',
            timestamp: new Date().toISOString(),
            environment: process.env.NODE_ENV || 'production',
            region: REGION,
            cognitoPool: COGNITO_USER_POOL_ID || 'not-configured',
            services: {
              cognito: !!cognito,
              dynamodb: !!dynamodb,
              configured: !!(COGNITO_USER_POOL_ID && COGNITO_CLIENT_ID)
            },
            sdkVersion: 'v3'
          });
        }
        break;
        
      case '/auth/register':
      case '/dev/auth/register':
        if (method === 'POST') {
          const { email, password, firstName, lastName, role = 'patient', phone } = requestBody;
          
          if (!email || !password) {
            return response(400, {
              success: false,
              error: 'Email and password are required'
            });
          }
          
          // Password validation
          if (password.length < 8) {
            return response(400, {
              success: false,
              error: 'Password must be at least 8 characters long'
            });
          }
          
          try {
            const { SignUpCommand } = require('@aws-sdk/client-cognito-identity-provider');
            
            // Register user with Cognito using AWS SDK v3
            const signUpParams = {
              ClientId: COGNITO_CLIENT_ID,
              Username: email,
              Password: password,
              UserAttributes: [
                { Name: 'email', Value: email },
                { Name: 'name', Value: `${firstName || ''} ${lastName || ''}`.trim() || email }
              ]
            };
            
            // Add phone if provided
            if (phone) {
              signUpParams.UserAttributes.push({ Name: 'phone_number', Value: phone });
            }
            
            // Add secret hash if client secret exists
            if (COGNITO_CLIENT_SECRET) {
              signUpParams.SecretHash = calculateSecretHash(email, COGNITO_CLIENT_ID, COGNITO_CLIENT_SECRET);
            }
            
            const command = new SignUpCommand(signUpParams);
            const result = await cognito.send(command);
            
            // Store user profile in DynamoDB
            try {
              const { PutCommand } = require('@aws-sdk/lib-dynamodb');
              const putCommand = new PutCommand({
                TableName: 'serenity-profiles',
                Item: {
                  userId: result.UserSub,
                  email: email,
                  firstName: firstName || '',
                  lastName: lastName || '',
                  role: role,
                  phone: phone || '',
                  createdAt: new Date().toISOString()
                }
              });
              await dynamodb.send(putCommand);
            } catch (err) {
              console.log('DynamoDB error (non-fatal):', err);
              // Continue even if DynamoDB fails
            }
            
            return response(200, {
              success: true,
              message: 'Registration successful! Please check your email for verification.',
              userSub: result.UserSub,
              codeDeliveryDetails: result.CodeDeliveryDetails
            });
            
          } catch (error) {
            console.error('Cognito registration error:', error);
            
            // Handle specific Cognito errors
            if (error.name === 'UsernameExistsException') {
              return response(400, {
                success: false,
                error: 'An account with this email already exists'
              });
            }
            
            if (error.name === 'InvalidPasswordException') {
              return response(400, {
                success: false,
                error: 'Password does not meet requirements. Must contain uppercase, lowercase, number, and special character.'
              });
            }
            
            return response(400, {
              success: false,
              error: error.message || 'Registration failed'
            });
          }
        }
        break;
        
      case '/auth/login':
      case '/dev/auth/login':
        if (method === 'POST') {
          const { email, password } = requestBody;
          
          if (!email || !password) {
            return response(400, {
              success: false,
              error: 'Email and password required'
            });
          }
          
          try {
            const { InitiateAuthCommand } = require('@aws-sdk/client-cognito-identity-provider');
            
            // Authenticate with Cognito using AWS SDK v3
            const authParams = {
              AuthFlow: 'USER_PASSWORD_AUTH',
              ClientId: COGNITO_CLIENT_ID,
              AuthParameters: {
                USERNAME: email,
                PASSWORD: password
              }
            };
            
            // Add secret hash if client secret exists
            if (COGNITO_CLIENT_SECRET) {
              authParams.AuthParameters.SECRET_HASH = calculateSecretHash(email, COGNITO_CLIENT_ID, COGNITO_CLIENT_SECRET);
            }
            
            const command = new InitiateAuthCommand(authParams);
            const result = await cognito.send(command);
            
            // Handle challenge if needed
            if (result.ChallengeName) {
              return response(200, {
                success: false,
                challenge: result.ChallengeName,
                session: result.Session,
                message: 'Additional verification required'
              });
            }
            
            return response(200, {
              success: true,
              tokens: {
                accessToken: result.AuthenticationResult.AccessToken,
                idToken: result.AuthenticationResult.IdToken,
                refreshToken: result.AuthenticationResult.RefreshToken,
                expiresIn: result.AuthenticationResult.ExpiresIn
              }
            });
            
          } catch (error) {
            console.error('Cognito login error:', error);
            
            if (error.name === 'NotAuthorizedException') {
              return response(401, {
                success: false,
                error: 'Invalid email or password'
              });
            }
            
            if (error.name === 'UserNotConfirmedException') {
              return response(401, {
                success: false,
                error: 'Please verify your email before logging in'
              });
            }
            
            return response(401, {
              success: false,
              error: error.message || 'Login failed'
            });
          }
        }
        break;
        
      case '/auth/user':
      case '/dev/auth/user':
        if (method === 'GET') {
          const authHeader = event.headers?.Authorization || event.headers?.authorization;
          
          if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return response(401, {
              success: false,
              error: 'No token provided'
            });
          }
          
          try {
            const { GetUserCommand } = require('@aws-sdk/client-cognito-identity-provider');
            
            const accessToken = authHeader.replace('Bearer ', '');
            
            // Get user info from Cognito
            const command = new GetUserCommand({
              AccessToken: accessToken
            });
            const user = await cognito.send(command);
            
            // Extract attributes
            const attributes = {};
            user.UserAttributes.forEach(attr => {
              attributes[attr.Name] = attr.Value;
            });
            
            // Try to get additional profile from DynamoDB
            let profile = {};
            if (attributes.sub) {
              try {
                const { GetCommand } = require('@aws-sdk/lib-dynamodb');
                const getCommand = new GetCommand({
                  TableName: 'serenity-profiles',
                  Key: { userId: attributes.sub }
                });
                const result = await dynamodb.send(getCommand);
                profile = result.Item || {};
              } catch (err) {
                console.log('DynamoDB profile fetch error:', err);
              }
            }
            
            return response(200, {
              success: true,
              user: {
                id: attributes.sub,
                email: attributes.email,
                firstName: profile.firstName || attributes.given_name || '',
                lastName: profile.lastName || attributes.family_name || '',
                role: profile.role || 'patient',
                emailVerified: attributes.email_verified === 'true'
              }
            });
            
          } catch (error) {
            console.error('Get user error:', error);
            return response(401, {
              success: false,
              error: 'Invalid or expired token'
            });
          }
        }
        break;
        
      case '/checkin':
      case '/dev/checkin':
        if (method === 'POST') {
          const { mood, anxiety, sleepHours, notes } = requestBody;
          const authHeader = event.headers?.Authorization || event.headers?.authorization;
          
          // For now, allow checkins without auth for testing
          let userId = 'anonymous';
          
          if (authHeader && authHeader.startsWith('Bearer ')) {
            try {
              const { GetUserCommand } = require('@aws-sdk/client-cognito-identity-provider');
              
              const accessToken = authHeader.replace('Bearer ', '');
              const command = new GetUserCommand({ AccessToken: accessToken });
              const user = await cognito.send(command);
              userId = user.UserAttributes.find(a => a.Name === 'sub')?.Value || 'anonymous';
            } catch (err) {
              console.log('Auth error for checkin, continuing as anonymous:', err);
            }
          }
          
          const checkInId = `checkin_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
          
          // Store in DynamoDB
          try {
            const { PutCommand } = require('@aws-sdk/lib-dynamodb');
            const putCommand = new PutCommand({
              TableName: 'serenity-checkins',
              Item: {
                checkInId,
                userId,
                mood: mood || 5,
                anxiety: anxiety || 5,
                sleepHours: sleepHours || 7,
                notes: notes || '',
                timestamp: new Date().toISOString()
              }
            });
            
            await dynamodb.send(putCommand);
            
            return response(200, {
              success: true,
              message: 'Check-in recorded successfully',
              checkInId,
              data: { mood, anxiety, sleepHours, notes }
            });
          } catch (err) {
            console.log('DynamoDB checkin error:', err);
            // Return success even if DynamoDB fails (for now)
            return response(200, {
              success: true,
              message: 'Check-in recorded (temporary storage)',
              checkInId,
              data: { mood, anxiety, sleepHours, notes }
            });
          }
        }
        break;
        
      case '/provider/dashboard':
      case '/dev/provider/dashboard':
        if (method === 'GET') {
          // TODO: Add proper auth check for provider role
          return response(200, {
            success: true,
            patients: [],
            alerts: [],
            metrics: {
              totalPatients: 42,
              activeToday: 15,
              crisisAlerts: 3,
              monthlyRevenue: '$45,000'
            }
          });
        }
        break;
        
      default:
        return response(404, {
          error: 'Not Found',
          path: path,
          method: method
        });
    }
    
    return response(405, {
      error: 'Method Not Allowed',
      path: path,
      method: method
    });
    
  } catch (error) {
    console.error('Lambda error:', error);
    return response(500, {
      error: 'Internal Server Error',
      message: error.message
    });
  }
};