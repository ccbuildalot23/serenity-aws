// Test handler to verify Lambda is working
exports.handler = async (event, context) => {
  console.log('Test handler invoked');
  console.log('Event:', JSON.stringify(event));
  
  return {
    statusCode: 200,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*'
    },
    body: JSON.stringify({
      message: 'Test handler working',
      timestamp: new Date().toISOString(),
      path: event.path || event.rawPath || '/',
      method: event.httpMethod || event.requestContext?.http?.method || 'GET'
    })
  };
};