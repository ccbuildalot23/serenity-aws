// Minimal test handler to see what's available in Lambda runtime
exports.handler = async (event, context) => {
  console.log('Event:', JSON.stringify(event));
  
  const response = (statusCode, body) => ({
    statusCode,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type,Authorization'
    },
    body: JSON.stringify(body)
  });
  
  // Check what AWS SDK versions are available
  let sdkInfo = { available: false };
  
  try {
    // Try AWS SDK v2
    const AWS = require('aws-sdk');
    sdkInfo.v2 = {
      available: true,
      version: AWS.VERSION || 'unknown'
    };
  } catch (err) {
    sdkInfo.v2 = {
      available: false,
      error: err.message
    };
  }
  
  try {
    // Try AWS SDK v3
    const { CognitoIdentityProviderClient } = require('@aws-sdk/client-cognito-identity-provider');
    sdkInfo.v3 = {
      available: true,
      cognitoClient: !!CognitoIdentityProviderClient
    };
  } catch (err) {
    sdkInfo.v3 = {
      available: false,
      error: err.message
    };
  }
  
  return response(200, {
    message: 'SDK Test Handler',
    environment: process.env.NODE_ENV,
    runtime: process.version,
    region: process.env.AWS_REGION || process.env.REGION,
    cognito: {
      userPoolId: process.env.COGNITO_USER_POOL_ID,
      clientId: process.env.COGNITO_CLIENT_ID,
      hasSecret: !!process.env.COGNITO_CLIENT_SECRET
    },
    sdkInfo
  });
};